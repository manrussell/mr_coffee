# LRAS1130

A library to control the AS1130 LED driver chip.

## API Documentation

https://luckyresistor.github.io/LRAS1130Docs/