var indexSectionsWithContent =
{
  0: "abcdfgilmprsw",
  1: "a",
  2: "l",
  3: "acfgirsw",
  4: "bcdfilmprs",
  5: "bcilmrs",
  6: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "enums",
  5: "enumvalues",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator",
  6: "Pages"
};

