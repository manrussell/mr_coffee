var searchData=
[
  ['lr',['lr',['../namespacelr.html',1,'']]]
];
