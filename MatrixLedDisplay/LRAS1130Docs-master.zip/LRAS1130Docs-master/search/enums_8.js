var searchData=
[
  ['ramconfiguration',['RamConfiguration',['../classlr_1_1_a_s1130.html#ae76a6d2a7b90b3e167af0c70c9f23efe',1,'lr::AS1130']]],
  ['registerselection',['RegisterSelection',['../classlr_1_1_a_s1130.html#a797f9b29dddf1a914653675e608aa862',1,'lr::AS1130']]]
];
