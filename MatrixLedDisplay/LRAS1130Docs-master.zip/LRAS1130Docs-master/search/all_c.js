var searchData=
[
  ['writecontrolregister',['writeControlRegister',['../classlr_1_1_a_s1130.html#a5f1dc490d3df6e5d3de7795cf68dcf02',1,'lr::AS1130']]],
  ['writecontrolregisterbits',['writeControlRegisterBits',['../classlr_1_1_a_s1130.html#a4288dcdc6eb946394c40b263d966ca79',1,'lr::AS1130']]],
  ['writeregisters',['writeRegisters',['../classlr_1_1_a_s1130_picture12x11.html#a0b448f07950810729a4151ec3d8214b2',1,'lr::AS1130Picture12x11::writeRegisters()'],['../classlr_1_1_a_s1130_picture24x5.html#af26687393aa37bdc5484a7527e8ce172',1,'lr::AS1130Picture24x5::writeRegisters()']]],
  ['writetochip',['writeToChip',['../classlr_1_1_a_s1130.html#a9d5045e4c0e83e60a57f66a6f9d69898',1,'lr::AS1130']]],
  ['writetomemory',['writeToMemory',['../classlr_1_1_a_s1130.html#a0d94c90013f1e0656b74a1873b2a673f',1,'lr::AS1130::writeToMemory(uint8_t registerSelection, uint8_t address, uint8_t data)'],['../classlr_1_1_a_s1130.html#af87d16fb1994182fb6b3db879e355144',1,'lr::AS1130::writeToMemory(uint8_t registerSelection, uint8_t address, const uint8_t *data, uint8_t size)']]]
];
