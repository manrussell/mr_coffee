# LRAS1130Docs
The API documentation for the LRAS1130 driver.
